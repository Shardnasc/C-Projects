﻿namespace Multiplication_Tables_Application
{
    partial class frmmulttable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblmulti = new System.Windows.Forms.Label();
            this.lblshow = new System.Windows.Forms.Label();
            this.lblto = new System.Windows.Forms.Label();
            this.txtnum = new System.Windows.Forms.TextBox();
            this.txttable = new System.Windows.Forms.TextBox();
            this.txtof = new System.Windows.Forms.TextBox();
            this.butshow = new System.Windows.Forms.Button();
            this.chckreverse = new System.Windows.Forms.CheckBox();
            this.helpProvider1 = new System.Windows.Forms.HelpProvider();
            this.ListBoxNum = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lblmulti
            // 
            this.lblmulti.AutoSize = true;
            this.lblmulti.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmulti.Location = new System.Drawing.Point(22, 27);
            this.lblmulti.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblmulti.Name = "lblmulti";
            this.lblmulti.Size = new System.Drawing.Size(216, 24);
            this.lblmulti.TabIndex = 0;
            this.lblmulti.Text = "Multiplication Table of:";
            // 
            // lblshow
            // 
            this.lblshow.AutoSize = true;
            this.lblshow.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblshow.Location = new System.Drawing.Point(24, 105);
            this.lblshow.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblshow.Name = "lblshow";
            this.lblshow.Size = new System.Drawing.Size(214, 24);
            this.lblshow.TabIndex = 1;
            this.lblshow.Text = "Showing from number:";
            // 
            // lblto
            // 
            this.lblto.AutoSize = true;
            this.lblto.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblto.Location = new System.Drawing.Point(24, 203);
            this.lblto.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblto.Name = "lblto";
            this.lblto.Size = new System.Drawing.Size(112, 24);
            this.lblto.TabIndex = 2;
            this.lblto.Text = "To number:";
            // 
            // txtnum
            // 
            this.txtnum.Location = new System.Drawing.Point(24, 233);
            this.txtnum.Margin = new System.Windows.Forms.Padding(6);
            this.txtnum.Name = "txtnum";
            this.txtnum.Size = new System.Drawing.Size(196, 32);
            this.txtnum.TabIndex = 3;
            this.txtnum.TextChanged += new System.EventHandler(this.txtnum_TextChanged);
            // 
            // txttable
            // 
            this.txttable.Location = new System.Drawing.Point(24, 67);
            this.txttable.Margin = new System.Windows.Forms.Padding(6);
            this.txttable.Name = "txttable";
            this.txttable.Size = new System.Drawing.Size(196, 32);
            this.txttable.TabIndex = 4;
            this.txttable.TextChanged += new System.EventHandler(this.txttable_TextChanged);
            // 
            // txtof
            // 
            this.txtof.Location = new System.Drawing.Point(24, 156);
            this.txtof.Margin = new System.Windows.Forms.Padding(6);
            this.txtof.Name = "txtof";
            this.txtof.Size = new System.Drawing.Size(196, 32);
            this.txtof.TabIndex = 5;
            this.txtof.TextChanged += new System.EventHandler(this.txtof_TextChanged);
            // 
            // butshow
            // 
            this.butshow.Location = new System.Drawing.Point(28, 308);
            this.butshow.Margin = new System.Windows.Forms.Padding(6);
            this.butshow.Name = "butshow";
            this.butshow.Size = new System.Drawing.Size(150, 42);
            this.butshow.TabIndex = 6;
            this.butshow.Text = "Show";
            this.butshow.UseVisualStyleBackColor = true;
            this.butshow.Click += new System.EventHandler(this.butshow_Click);
            // 
            // chckreverse
            // 
            this.chckreverse.AutoSize = true;
            this.chckreverse.Location = new System.Drawing.Point(35, 385);
            this.chckreverse.Margin = new System.Windows.Forms.Padding(6);
            this.chckreverse.Name = "chckreverse";
            this.chckreverse.Size = new System.Drawing.Size(101, 28);
            this.chckreverse.TabIndex = 7;
            this.chckreverse.Text = "Reverse";
            this.chckreverse.UseVisualStyleBackColor = true;
            this.chckreverse.CheckedChanged += new System.EventHandler(this.chckreverse_CheckedChanged);
            // 
            // ListBoxNum
            // 
            this.ListBoxNum.BackColor = System.Drawing.SystemColors.MenuBar;
            this.ListBoxNum.FormattingEnabled = true;
            this.ListBoxNum.ItemHeight = 24;
            this.ListBoxNum.Location = new System.Drawing.Point(292, 41);
            this.ListBoxNum.Name = "ListBoxNum";
            this.ListBoxNum.Size = new System.Drawing.Size(204, 292);
            this.ListBoxNum.TabIndex = 9;
            this.ListBoxNum.SelectedIndexChanged += new System.EventHandler(this.ListBox_SelectedIndexChanged_1);
            // 
            // frmmulttable
            // 
            this.AcceptButton = this.butshow;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(735, 531);
            this.Controls.Add(this.ListBoxNum);
            this.Controls.Add(this.chckreverse);
            this.Controls.Add(this.butshow);
            this.Controls.Add(this.txtof);
            this.Controls.Add(this.txttable);
            this.Controls.Add(this.txtnum);
            this.Controls.Add(this.lblto);
            this.Controls.Add(this.lblshow);
            this.Controls.Add(this.lblmulti);
            this.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "frmmulttable";
            this.ShowIcon = false;
            this.Text = "Multiplication Table";
            this.Load += new System.EventHandler(this.frmmulttable_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblmulti;
        private System.Windows.Forms.Label lblshow;
        private System.Windows.Forms.Label lblto;
        private System.Windows.Forms.TextBox txtnum;
        private System.Windows.Forms.TextBox txttable;
        private System.Windows.Forms.TextBox txtof;
        private System.Windows.Forms.Button butshow;
        private System.Windows.Forms.CheckBox chckreverse;
        private System.Windows.Forms.HelpProvider helpProvider1;
        private System.Windows.Forms.ListBox ListBoxNum;
    }
}

