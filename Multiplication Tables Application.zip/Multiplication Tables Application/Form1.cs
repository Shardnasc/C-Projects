﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Multiplication_Tables_Application
{
    public partial class frmmulttable : Form
    {
        public frmmulttable()
        {
            InitializeComponent();
        }

        private void butshow_Click(object sender, EventArgs e)
        {
           
            //Using int 0 for convert 32 bit. Also, using clear for the show display.
            
            int m;
            int listtable = 0;
            int shownumberof = 0;
            int tonumber = 0;

            listtable = Convert.ToInt32(txttable.Text);
            shownumberof = Convert.ToInt32(txtof.Text);
            tonumber = Convert.ToInt32(txtnum.Text);
            ListBoxNum.Items.Clear();
            
            /*This is my reverse for checked being discussed in class. Additionally, the discussion was based
            from the conversaion when false is uncheck. Additionally,*/

            if (chckreverse.Checked == false)
            {
               

                for (m = shownumberof; m <= tonumber; m++)
                
                ListBoxNum.Items.Add(listtable + " x " + m + " = " + (listtable * m));
            }

            else
            {

                for (m = tonumber; m >= shownumberof; m--)
                {

                    ListBoxNum.Items.Add(listtable + " x " + m + " = " + (listtable * m));
                }

                

            }
        }

    private void txttable_TextChanged(object sender, EventArgs e)
    {

    }

    private void txtlist_TextChanged(object sender, EventArgs e)
    {

    }

    private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
    {

    }

    private void listbox_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    private void txtlist_TextChanged_1(object sender, EventArgs e)
    {

    }

    private void txtof_TextChanged(object sender, EventArgs e)
    {

    }

    private void txtnum_TextChanged(object sender, EventArgs e)
    {

    }

    private void frmmulttable_Load(object sender, EventArgs e)
    {
        txtof.Focus();
    }

    private void chckreverse_CheckedChanged(object sender, EventArgs e)
    {

    }

        private void ListBox_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    } // end class
} // end ns
