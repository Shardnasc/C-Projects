﻿namespace Rock_Paper_Scissors_Game_App
{
    partial class Gamefrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblscore = new System.Windows.Forms.Label();
            this.lblcomp = new System.Windows.Forms.Label();
            this.lbloutput = new System.Windows.Forms.Label();
            this.buttonplay = new System.Windows.Forms.Button();
            this.buttonexit = new System.Windows.Forms.Button();
            this.txtcompscore = new System.Windows.Forms.TextBox();
            this.txtyourscore = new System.Windows.Forms.TextBox();
            this.txtcomp = new System.Windows.Forms.TextBox();
            this.radioRock = new System.Windows.Forms.RadioButton();
            this.radioPaper = new System.Windows.Forms.RadioButton();
            this.radioScissors = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.lbloutputcomp = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblscore
            // 
            this.lblscore.AutoSize = true;
            this.lblscore.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblscore.Location = new System.Drawing.Point(51, 29);
            this.lblscore.Name = "lblscore";
            this.lblscore.Size = new System.Drawing.Size(164, 36);
            this.lblscore.TabIndex = 0;
            this.lblscore.Text = "Your Score";
            // 
            // lblcomp
            // 
            this.lblcomp.AutoSize = true;
            this.lblcomp.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcomp.Location = new System.Drawing.Point(264, 29);
            this.lblcomp.Name = "lblcomp";
            this.lblcomp.Size = new System.Drawing.Size(260, 36);
            this.lblcomp.TabIndex = 1;
            this.lblcomp.Text = "Computer\'s Score";
            // 
            // lbloutput
            // 
            this.lbloutput.AutoSize = true;
            this.lbloutput.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbloutput.Location = new System.Drawing.Point(55, 287);
            this.lbloutput.Name = "lbloutput";
            this.lbloutput.Size = new System.Drawing.Size(199, 36);
            this.lbloutput.TabIndex = 2;
            this.lbloutput.Text = "Output Score";
            this.lbloutput.Click += new System.EventHandler(this.lbloutput_Click);
            // 
            // buttonplay
            // 
            this.buttonplay.Location = new System.Drawing.Point(80, 343);
            this.buttonplay.Name = "buttonplay";
            this.buttonplay.Size = new System.Drawing.Size(147, 44);
            this.buttonplay.TabIndex = 3;
            this.buttonplay.Text = "Play!";
            this.buttonplay.UseVisualStyleBackColor = true;
            this.buttonplay.Click += new System.EventHandler(this.buttonplay_Click);
            // 
            // buttonexit
            // 
            this.buttonexit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonexit.Location = new System.Drawing.Point(476, 343);
            this.buttonexit.Name = "buttonexit";
            this.buttonexit.Size = new System.Drawing.Size(147, 44);
            this.buttonexit.TabIndex = 6;
            this.buttonexit.Text = "Exit";
            this.buttonexit.UseVisualStyleBackColor = true;
            this.buttonexit.Click += new System.EventHandler(this.buttonexit_Click);
            // 
            // txtcompscore
            // 
            this.txtcompscore.Location = new System.Drawing.Point(366, 78);
            this.txtcompscore.Multiline = true;
            this.txtcompscore.Name = "txtcompscore";
            this.txtcompscore.Size = new System.Drawing.Size(94, 42);
            this.txtcompscore.TabIndex = 7;
            this.txtcompscore.TextChanged += new System.EventHandler(this.txtcompscore_TextChanged);
            // 
            // txtyourscore
            // 
            this.txtyourscore.Location = new System.Drawing.Point(80, 78);
            this.txtyourscore.Multiline = true;
            this.txtyourscore.Name = "txtyourscore";
            this.txtyourscore.Size = new System.Drawing.Size(94, 42);
            this.txtyourscore.TabIndex = 8;
            this.txtyourscore.TextChanged += new System.EventHandler(this.txtyourscore_TextChanged);
            // 
            // txtcomp
            // 
            this.txtcomp.Location = new System.Drawing.Point(338, 138);
            this.txtcomp.Multiline = true;
            this.txtcomp.Name = "txtcomp";
            this.txtcomp.Size = new System.Drawing.Size(150, 146);
            this.txtcomp.TabIndex = 9;
            this.txtcomp.TextChanged += new System.EventHandler(this.txtcomp_TextChanged);
            // 
            // radioRock
            // 
            this.radioRock.AutoSize = true;
            this.radioRock.BackColor = System.Drawing.SystemColors.Control;
            this.radioRock.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioRock.Location = new System.Drawing.Point(19, 31);
            this.radioRock.Name = "radioRock";
            this.radioRock.Size = new System.Drawing.Size(62, 22);
            this.radioRock.TabIndex = 11;
            this.radioRock.TabStop = true;
            this.radioRock.Text = "Rock";
            this.radioRock.UseVisualStyleBackColor = false;
            this.radioRock.CheckedChanged += new System.EventHandler(this.radioRock_CheckedChanged);
            // 
            // radioPaper
            // 
            this.radioPaper.AutoSize = true;
            this.radioPaper.BackColor = System.Drawing.SystemColors.Control;
            this.radioPaper.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioPaper.Location = new System.Drawing.Point(109, 31);
            this.radioPaper.Name = "radioPaper";
            this.radioPaper.Size = new System.Drawing.Size(65, 22);
            this.radioPaper.TabIndex = 12;
            this.radioPaper.TabStop = true;
            this.radioPaper.Text = "Paper";
            this.radioPaper.UseVisualStyleBackColor = false;
            this.radioPaper.CheckedChanged += new System.EventHandler(this.radioPaper_CheckedChanged);
            // 
            // radioScissors
            // 
            this.radioScissors.AutoSize = true;
            this.radioScissors.BackColor = System.Drawing.SystemColors.Control;
            this.radioScissors.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioScissors.Location = new System.Drawing.Point(19, 72);
            this.radioScissors.Name = "radioScissors";
            this.radioScissors.Size = new System.Drawing.Size(85, 22);
            this.radioScissors.TabIndex = 13;
            this.radioScissors.TabStop = true;
            this.radioScissors.Text = "Scissors";
            this.radioScissors.UseVisualStyleBackColor = false;
            this.radioScissors.CheckedChanged += new System.EventHandler(this.radioScissors_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(334, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 22);
            this.label2.TabIndex = 15;
            this.label2.Text = "Computer\'s Move";
            // 
            // lbloutputcomp
            // 
            this.lbloutputcomp.AutoSize = true;
            this.lbloutputcomp.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.lbloutputcomp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbloutputcomp.Location = new System.Drawing.Point(350, 210);
            this.lbloutputcomp.Name = "lbloutputcomp";
            this.lbloutputcomp.Size = new System.Drawing.Size(122, 24);
            this.lbloutputcomp.TabIndex = 16;
            this.lbloutputcomp.Text = "Output Comp";
            this.lbloutputcomp.Click += new System.EventHandler(this.lbloutputcomp_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioScissors);
            this.groupBox1.Controls.Add(this.radioPaper);
            this.groupBox1.Controls.Add(this.radioRock);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(54, 140);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(217, 144);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Your Move";
            // 
            // Gamefrm
            // 
            this.AcceptButton = this.buttonplay;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CancelButton = this.buttonexit;
            this.ClientSize = new System.Drawing.Size(713, 408);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lbloutputcomp);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtcomp);
            this.Controls.Add(this.txtyourscore);
            this.Controls.Add(this.txtcompscore);
            this.Controls.Add(this.buttonexit);
            this.Controls.Add(this.buttonplay);
            this.Controls.Add(this.lbloutput);
            this.Controls.Add(this.lblcomp);
            this.Controls.Add(this.lblscore);
            this.Name = "Gamefrm";
            this.ShowIcon = false;
            this.Text = "Rock, Paper, Scissors!";
            this.Load += new System.EventHandler(this.Gamefrm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblscore;
        private System.Windows.Forms.Label lblcomp;
        private System.Windows.Forms.Button buttonplay;
        private System.Windows.Forms.Button buttonexit;
        private System.Windows.Forms.TextBox txtcompscore;
        private System.Windows.Forms.TextBox txtyourscore;
        private System.Windows.Forms.TextBox txtcomp;
        private System.Windows.Forms.RadioButton radioRock;
        private System.Windows.Forms.RadioButton radioPaper;
        private System.Windows.Forms.RadioButton radioScissors;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbloutput;
        private System.Windows.Forms.Label lbloutputcomp;
    }
}

