﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rock_Paper_Scissors_Game_App
{
    public partial class Gamefrm : Form
    {

       
        public Gamefrm()
        {
            InitializeComponent();
        }
        //the scores of the userscore and computerscore in the form
        int userscore = 0;
        int computerscore = 0;



        private void listP2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listP1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lbloutput_Click(object sender, EventArgs e)
        {

        }

        private void buttonexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonplay_Click(object sender, EventArgs e)
        {
            int user = 0;
            int computer = 0;
            /* Random generator: one for rock, two for paper,
            and three for scissors */
            
            Random rnd = new Random();
            computer = rnd.Next(1, 4);

           

           //if and else statement for radio selections of the game
            if (radioRock.Checked)
                user = 1;
            else if (radioPaper.Checked)
                user = 2;
            else if (radioScissors.Checked)
                user = 3;
            //if and else statement for computer selections
            
            if (computer == 1)
                lbloutputcomp.Text = "Rock";
            else if (computer == 2)
                lbloutputcomp.Text = "Paper";
            else if (computer == 3)
                lbloutputcomp.Text = "Scissors";
            
            //string to text inserting in " "
            string p1move = "";
            string p2move = "";
            
            //getting p1 moves
            if (user == 1)
                p1move = "Rock";
            else if (user == 2)
                p1move = "Paper";
            else if (user == 3)
                p1move = "Scissors";

            //getting p2 moves
            if (computer == 1)
                p2move = "Rock";
            else if (computer == 2)
                p2move = "Paper";
            else if (computer == 3)
                p2move = "Scissors";
            
            //this is how the possibiliites of the game works sum in this syntax and using II for or and && for and
            
            if ((user == 2 && computer == 1) || (user ==3 && computer ==2 ) || (user == 1 && computer ==3))
            //this is the label output
            
           
            {
                lbloutput.Text = p1move + " and " + p2move + ". User won!";
                userscore++;
            }
            //if and else for when user == if true/false 
            else
            
            if (user == computer)
            {
                lbloutput.Text = p1move + " and " + p2move + ". It's a tie!";
            }
            else
            {
                lbloutput.Text = p1move + " and " + p2move + ". Computer wins!";
                
                computerscore++; 
            }


            

            //Display scores
            txtyourscore.Text = userscore.ToString();
            txtcompscore.Text = computerscore.ToString();




        }//end buttonplay

        
        

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void txtcomp_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtyour_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtyourscore_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtcompscore_TextChanged(object sender, EventArgs e)
        {

        }

        private void Gamefrm_Load(object sender, EventArgs e)
        {
            //scores for the game when loading in
            txtyourscore.Text = userscore.ToString();
            txtcompscore.Text = computerscore.ToString();

        }
        
        // All check.changed radio buttons have "" for the output hidden when selected
        private void radioRock_CheckedChanged(object sender, EventArgs e)
        {
            lbloutputcomp.Text = "";
            lbloutput.Text = "";

        }

        private void radioPaper_CheckedChanged(object sender, EventArgs e)
        {
            lbloutputcomp.Text = "";
            lbloutput.Text = "";
        }

        private void radioScissors_CheckedChanged(object sender, EventArgs e)
        {
            lbloutputcomp.Text = "";
            lbloutput.Text = "";
        }

        private void lbloutputcomp_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            
        }
    }//end class
}//end ns
