﻿namespace Store_Contact_Information
{
    partial class mainfrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.addbut = new System.Windows.Forms.Button();
            this.findbut = new System.Windows.Forms.Button();
            this.closebut = new System.Windows.Forms.Button();
            this.upbut = new System.Windows.Forms.Button();
            this.sortbut = new System.Windows.Forms.Button();
            this.txtDocument = new System.Windows.Forms.TextBox();
            this.lblInt = new System.Windows.Forms.Label();
            this.lbllimit = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 56);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 104);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "E-mail";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 160);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "Phone";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(141, 58);
            this.txtname.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(197, 29);
            this.txtname.TabIndex = 3;
            this.txtname.TextChanged += new System.EventHandler(this.txtname_TextChanged);
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(141, 107);
            this.txtemail.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(197, 29);
            this.txtemail.TabIndex = 4;
            this.txtemail.TextChanged += new System.EventHandler(this.txtemail_TextChanged);
            // 
            // txtphone
            // 
            this.txtphone.Location = new System.Drawing.Point(141, 157);
            this.txtphone.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(197, 29);
            this.txtphone.TabIndex = 5;
            this.txtphone.TextChanged += new System.EventHandler(this.txtphone_TextChanged);
            // 
            // addbut
            // 
            this.addbut.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addbut.Location = new System.Drawing.Point(20, 270);
            this.addbut.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.addbut.Name = "addbut";
            this.addbut.Size = new System.Drawing.Size(153, 54);
            this.addbut.TabIndex = 6;
            this.addbut.Text = "Add";
            this.addbut.UseVisualStyleBackColor = true;
            this.addbut.Click += new System.EventHandler(this.addbut_Click);
            // 
            // findbut
            // 
            this.findbut.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.findbut.Location = new System.Drawing.Point(217, 342);
            this.findbut.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.findbut.Name = "findbut";
            this.findbut.Size = new System.Drawing.Size(153, 54);
            this.findbut.TabIndex = 7;
            this.findbut.Text = "Find Name";
            this.findbut.UseVisualStyleBackColor = true;
            this.findbut.Click += new System.EventHandler(this.findbut_Click);
            // 
            // closebut
            // 
            this.closebut.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closebut.Location = new System.Drawing.Point(20, 580);
            this.closebut.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.closebut.Name = "closebut";
            this.closebut.Size = new System.Drawing.Size(153, 54);
            this.closebut.TabIndex = 8;
            this.closebut.Text = "Close";
            this.closebut.UseVisualStyleBackColor = true;
            this.closebut.Click += new System.EventHandler(this.closebut_Click);
            // 
            // upbut
            // 
            this.upbut.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.upbut.Location = new System.Drawing.Point(20, 342);
            this.upbut.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.upbut.Name = "upbut";
            this.upbut.Size = new System.Drawing.Size(153, 54);
            this.upbut.TabIndex = 9;
            this.upbut.Text = "Update";
            this.upbut.UseVisualStyleBackColor = true;
            this.upbut.Click += new System.EventHandler(this.upbut_Click);
            // 
            // sortbut
            // 
            this.sortbut.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sortbut.Location = new System.Drawing.Point(217, 270);
            this.sortbut.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.sortbut.Name = "sortbut";
            this.sortbut.Size = new System.Drawing.Size(153, 54);
            this.sortbut.TabIndex = 10;
            this.sortbut.Text = "Sort by Name";
            this.sortbut.UseVisualStyleBackColor = true;
            this.sortbut.Click += new System.EventHandler(this.sortbut_Click);
            // 
            // txtDocument
            // 
            this.txtDocument.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDocument.Location = new System.Drawing.Point(450, 107);
            this.txtDocument.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtDocument.Multiline = true;
            this.txtDocument.Name = "txtDocument";
            this.txtDocument.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDocument.Size = new System.Drawing.Size(289, 288);
            this.txtDocument.TabIndex = 6;
            this.txtDocument.TextChanged += new System.EventHandler(this.TxtDocument_TextChanged);
            // 
            // lblInt
            // 
            this.lblInt.AutoSize = true;
            this.lblInt.Font = new System.Drawing.Font("Microsoft YaHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInt.Location = new System.Drawing.Point(26, 14);
            this.lblInt.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblInt.Name = "lblInt";
            this.lblInt.Size = new System.Drawing.Size(301, 22);
            this.lblInt.TabIndex = 12;
            this.lblInt.Text = "Please insert your information here.";
            // 
            // lbllimit
            // 
            this.lbllimit.AutoSize = true;
            this.lbllimit.Font = new System.Drawing.Font("Microsoft YaHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllimit.Location = new System.Drawing.Point(466, 59);
            this.lbllimit.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lbllimit.Name = "lbllimit";
            this.lbllimit.Size = new System.Drawing.Size(115, 22);
            this.lbllimit.TabIndex = 13;
            this.lbllimit.Text = "Limit Output";
            this.lbllimit.Click += new System.EventHandler(this.lbllimit_Click);
            // 
            // mainfrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(863, 646);
            this.Controls.Add(this.lbllimit);
            this.Controls.Add(this.lblInt);
            this.Controls.Add(this.txtDocument);
            this.Controls.Add(this.sortbut);
            this.Controls.Add(this.upbut);
            this.Controls.Add(this.closebut);
            this.Controls.Add(this.findbut);
            this.Controls.Add(this.addbut);
            this.Controls.Add(this.txtphone);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft YaHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "mainfrm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Contact Info";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.Button addbut;
        private System.Windows.Forms.Button findbut;
        private System.Windows.Forms.Button closebut;
        private System.Windows.Forms.Button upbut;
        private System.Windows.Forms.Button sortbut;
        private System.Windows.Forms.TextBox txtDocument;
        private System.Windows.Forms.Label lblInt;
        private System.Windows.Forms.Label lbllimit;
    }
}

