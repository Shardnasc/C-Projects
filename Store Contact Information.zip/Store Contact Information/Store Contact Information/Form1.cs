﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace Store_Contact_Information
{
    public partial class mainfrm : Form
    {

        /*Setting up a class with private strings and 
        public strings. I had to capitalized peoplesname, email,
       and phone. I used get/set and return for the texts.
        As mentioned, I can either create another class .cs or
        put it in here
       */
        private string peoplesname;
        private string email;
        private string phone;

        public string PeoplesName
        {
            get
            {
                return PeoplesName;
            }
            set
            {
                PeoplesName = value;
            }
        }

        public string Email
        {
            get
            {
                return Email;
            }
            set
            {
                email = value;
            }

        }

        public string Phone
        {
            get
            {
                return Phone;
            }
            set
            {
                phone = value;
            }
        }
        /*overriding a string for this label for \r\n. If not it will display
        "store contact information." Finding this override syntax took me a while*/
        public override string ToString()
        {
            return "Name:" + peoplesname + "\r\nEmail:" + email + "\r\nPhone:" + phone + "\r\n=====================\r\n";
        }
    
        public mainfrm()
        /*This is the limit output for the name, email, and phone.
         Also I used the array count and Math.Max (specific number input) */
        {
            InitializeComponent();
            lbllimit.Text = counter + "/" + MAX;
        }
        /* Math Max and using constant so others or myself 
        to overwrite values-from W3Schools tutorial.*/
        const int MAX = 10;
        int counter = 0;

        mainfrm[] mainfrms = new mainfrm[MAX];

        //This shows count list size from Array List notes. I used [] operator instead of ().
        public void show()
        {
            lbllimit.Text = counter + "/" + MAX;

            for (int i = 0; i < counter; i++) 
            {
                txtDocument.Text += mainfrms[i];
            }
        }
        /*I created a public int and string.ToLower for mainfrms (public void class).
        This is for lowercases.  */
        public int Document(string R)
        {
            for (int i = 0; i < counter; i++)
            {
                if (mainfrms[i].peoplesname.ToLower().Equals(R.ToLower()))
                {

                    return i;
                }
            }
            {
                return -1;
            }
        }
        /*This public void clears out the name, email, and phone
        when*/
        public void clear()
        {

            txtname.Clear();

            txtemail.Clear();

            txtphone.Clear();

        }
        


        private void closebut_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void addbut_Click(object sender, EventArgs e)
        {

            //Using || for "or" like x or y. Messageboxes for the requirements
            //I use .equals and not = or == because to check if it is true.

            if (txtemail.Text.Equals("") || txtname.Text.Equals("") || txtphone.Text.Equals(""))

            {
                MessageBox.Show("Please enter all information");

            }
            else
            {
                if (counter == 10)
                {
                    MessageBox.Show("Maxmium has been reached");

                }
              //using the class mainfrm
               else
                {
                    mainfrm mainfrm = new mainfrm();
                    //this is the class mainfrm letting the user input to the textboxes
                    mainfrm.peoplesname = txtname.Text;
                    mainfrm.email = txtemail.Text;
                    mainfrm.phone = txtphone.Text;
                    mainfrms[counter] = mainfrm;
                    txtDocument.Text = "=====ADD========\r\n";
                    counter++;
                    show();
                    clear();

                }
            }
         }

        private void lbllimit_Click(object sender, EventArgs e)
        {

        }

        private void txtname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtemail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtphone_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtDocument_TextChanged(object sender, EventArgs e)
        {

        }

        private void findbut_Click(object sender, EventArgs e)
        {
            //Using if and else for messagebox requirements
            if (txtname.Equals(""))
            {
                MessageBox.Show("Please enter Name to find Document:");
            }
            else
            /*I create an int so if a user input a name and it is
            not found, then it showed "contact not found"
            square brackets are used from array list*/
                {
                int number = Document(txtname.Text);
                if (number == -1)
                {
                    MessageBox.Show("Contact not found");
                }
                else
                {
                    txtname.Text = mainfrms[number].peoplesname;
                    txtemail.Text = mainfrms[number].email;
                    txtphone.Text = mainfrms[number].phone;
                }
            }
          }

        private void upbut_Click(object sender, EventArgs e)
        {
            //if and else for messagebox. I used -1 removal if input isn't found
            if (txtname.Text.Equals(""))
            {
                MessageBox.Show("Please enter name to find and update record:");
            }
            //for the textbox when can't find contact and .equals input "".
            else
            {
                int number = Document(txtname.Text);
                if (number == -1)
                {
                    MessageBox.Show("Contact not found:");
                }
                else
                {
                    if (txtname.Text.Equals(""))
                        mainfrms[number].peoplesname = txtname.Text;

                    if (txtemail.Text.Equals(""))
                        mainfrms[number].Email = txtemail.Text;
                    if (txtphone.Text.Equals(""))
                        mainfrms[number].Phone = txtphone.Text;
                    
                    txtDocument.Text = "====Update========\r\n";
                    show();
                }
            }
            



        }
        
        private void sortbut_Click(object sender, EventArgs e)
        {
            //Using clas mainfrm and the int counter=0 for user to put many inputs.
            mainfrm[] random = new mainfrm[counter];
            for (int i=0; i< counter; i++)
            {
                random[i] = mainfrms[i];
            }
            //Using array.sort to sort x and y into these variables.
            Array.Sort(random, (x, y) => String.Compare(x.peoplesname, y.peoplesname));
            
            //This is the limit output of int counter and max by ten fill ins.
            
            lbllimit.Text = counter + "/" + MAX;
            //For the main output putting a phrase
            txtDocument.Clear();
            txtDocument.Text = "=== Please sort by name====\r\n";
            for (int i=0; i <counter; i++)
            {
                txtDocument.Text += random[i];
            }
        }
       
    
    
    }//end main
}//end ns
